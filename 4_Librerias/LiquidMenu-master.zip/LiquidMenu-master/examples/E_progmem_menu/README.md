Example 5: progmem_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/E_progmem_menu/progmem_menu.png?raw=true)
This example demonstrates how to display a string stored in flash memory.
